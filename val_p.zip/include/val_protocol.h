#ifndef VAL_PROTOCOL_H
#define VAL_PROTOCOL_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <stddef.h>
#include <stdint.h>

// Protocol constants
#define VAL_MAGIC 0x56414C00u // "VAL\0"
#define VAL_VERSION_MAJOR 0u
#define VAL_VERSION_MINOR 5u
#define VAL_MIN_PACKET_SIZE 512u
#define VAL_MAX_PACKET_SIZE 65536u
#define VAL_MAX_FILENAME 255u
#define VAL_MAX_PATH 255u

    // Status codes
    typedef enum
    {
        VAL_OK = 0,
        VAL_ERR_INVALID_ARG = -1,
        VAL_ERR_NO_MEMORY = -2,
        VAL_ERR_IO = -3,
        VAL_ERR_TIMEOUT = -4,
        VAL_ERR_PROTOCOL = -5,
        VAL_ERR_CRC = -6,
        VAL_ERR_RESUME_VERIFY = -7,
        VAL_ERR_INCOMPATIBLE_VERSION = -8,
        VAL_ERR_PACKET_SIZE_MISMATCH = -9,
        VAL_ERR_FEATURE_NEGOTIATION = -10,
    } val_status_t;

    typedef enum
    {
        VAL_RESUME_NONE = 0,
        VAL_RESUME_APPEND = 1,
        VAL_RESUME_CRC_VERIFY = 2,
    } val_resume_mode_t;

    typedef struct val_session_s val_session_t;

// Public feature bits (use in config.features.required/requested)
#define VAL_FEAT_NONE 0u
#define VAL_FEAT_CRC_RESUME (1u << 0)
#define VAL_FEAT_MULTI_FILES (1u << 1)

    typedef struct
    {
        // Thread-safety: Unless otherwise stated, a single val_session_t must not be used concurrently from multiple threads.
        // Create one session per direction/worker, or add your own external synchronization around public APIs. Different
        // sessions can be used in parallel safely. Callbacks must be non-reentrant (do not call back into the same session).
        struct
        {
            // Send exactly 'len' bytes (may be smaller than packet_size for final frames). Return bytes sent or <0 on error.
            int (*send)(void *ctx, const void *data, size_t len);
            // Receive exactly 'buffer_size' bytes, blocking until filled or timeout. Return 0 on success, <0 on error.
            // The protocol reads header, then payload_len, then trailer CRC in separate calls.
            int (*recv)(void *ctx, void *buffer, size_t buffer_size, size_t *received, uint32_t timeout_ms);
            void *io_context;
        } transport;

        struct
        {
            void *(*fopen)(void *ctx, const char *path, const char *mode);
            int (*fread)(void *ctx, void *buffer, size_t size, size_t count, void *file);
            int (*fwrite)(void *ctx, const void *buffer, size_t size, size_t count, void *file);
            int (*fseek)(void *ctx, void *file, long offset, int whence);
            long (*ftell)(void *ctx, void *file);
            int (*fclose)(void *ctx, void *file);
            void *fs_context;
        } filesystem;

        // Optional CRC32 provider (e.g., hardware-accelerated). If any pointer is NULL, built-in software is used.
        struct
        {
            uint32_t (*crc32)(void *ctx, const void *data, size_t length); // one-shot
            uint32_t (*crc32_init)(void *ctx);                             // returns initial state
            uint32_t (*crc32_update)(void *ctx, uint32_t state, const void *data, size_t length);
            uint32_t (*crc32_final)(void *ctx, uint32_t state); // returns final CRC32
            void *crc_context;                                  // user context passed to hooks
        } crc;

        struct
        {
            uint32_t (*get_ticks_ms)(void);
            void (*delay_ms)(uint32_t ms);
        } system;

        // Timeouts (ms). Zero values pick sensible defaults.
        struct
        {
            uint32_t handshake_ms; // initial hello exchange
            uint32_t meta_ms;      // metadata send/receive
            uint32_t data_ms;      // data packet receive
            uint32_t ack_ms;       // ack wait per chunk
            uint32_t idle_ms;      // idle wait between files
        } timeouts;

        // Feature requirements and requests (used during handshake)
        // Note: Actual supported features are baked in at compile time and not user-editable.
        struct
        {
            uint32_t required;  // features that must be present on peer; masked to built-in features internally
            uint32_t requested; // features requested if peer supports; masked to built-in features internally
        } features;

        // Retry policy and backoff for timeouts
        struct
        {
            uint8_t meta_retries;     // retries for waiting metadata (on timeout)
            uint8_t data_retries;     // retries for waiting data (on timeout)
            uint8_t ack_retries;      // retries for waiting ACK (on timeout)
            uint32_t backoff_ms_base; // base backoff between retries (exponential: base, 2*base, ...)
        } retries;

        struct
        {
            void *send_buffer;  // At least packet_size bytes; used as staging for header+payload+crc
            void *recv_buffer;  // At least packet_size bytes; used to read header and payload
            size_t packet_size; // MTU (max frame size), not a strict per-packet size
        } buffers;

        struct
        {
            val_resume_mode_t mode;
            uint32_t verify_bytes;
        } resume;

        struct
        {
            // Filenames and sender_path are treated as UTF-8 on wire and in callbacks. Sanitizers preserve non-ASCII bytes
            // but may truncate at a byte boundary to fit size limits. Applications should treat these as UTF-8 strings.
            void (*on_file_start)(const char *filename, const char *sender_path, uint64_t file_size, uint64_t resume_offset);
            void (*on_file_complete)(const char *filename, const char *sender_path, val_status_t result);
            void (*on_progress)(uint64_t bytes_transferred, uint64_t total_bytes);
        } callbacks;
    } val_config_t;

    // API
    val_session_t *val_session_create(const val_config_t *config);
    void val_session_destroy(val_session_t *session);

    // Send multiple files; array of paths (you can pass 1 or many). Stops on first error.
    val_status_t val_send_files(val_session_t *session, const char *const *filepaths, size_t file_count, const char *sender_path);
    val_status_t val_receive_files(val_session_t *session, const char *output_directory);

    // Utilities
    void val_clean_filename(const char *input, char *output, size_t output_size);
    void val_clean_path(const char *input, char *output, size_t output_size);
    uint32_t val_crc32(const void *data, size_t length);

    // Query compiled-in features (what this build supports)
    uint32_t val_get_builtin_features(void);

    // Retrieve last error info recorded by the session (code and optional detail mask)
    val_status_t val_get_last_error(val_session_t *session, val_status_t *code, uint32_t *detail_mask);

#ifdef __cplusplus
}
#endif

#endif // VAL_PROTOCOL_H
