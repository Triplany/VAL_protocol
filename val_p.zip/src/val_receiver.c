#include "val_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static val_status_t send_resume_response(val_session_t *s, val_resume_action_t action, uint64_t offset, uint32_t crc,
                                         uint32_t verify_len)
{
    val_resume_resp_t resp;
    resp.action = val_htole32((uint32_t)action);
    resp.resume_offset = val_htole64(offset);
    resp.verify_crc = val_htole32(crc);
    resp.verify_len = val_htole32(verify_len);
    return val_internal_send_packet(s, VAL_PKT_RESUME_RESP, &resp, sizeof(resp), offset);
}

static val_status_t handle_verification_exchange(val_session_t *s, uint32_t expected_crc)
{
    // Wait for sender to echo back the CRC in a VERIFY packet
    uint8_t buf[128];
    uint32_t len = 0;
    uint64_t off = 0;
    val_packet_type_t t = 0;
    val_status_t st = val_internal_recv_packet(s, &t, buf, sizeof(buf), &len, &off, 10000);
    if (st != VAL_OK)
        return st;
    if (t != VAL_PKT_VERIFY)
        return VAL_ERR_PROTOCOL;
    if (len < sizeof(val_resume_resp_t))
        return VAL_ERR_PROTOCOL;
    val_resume_resp_t their;
    memcpy(&their, buf, sizeof(their));
    // Convert from LE
    their.action = val_letoh32(their.action);
    their.resume_offset = val_letoh64(their.resume_offset);
    their.verify_crc = val_letoh32(their.verify_crc);
    their.verify_len = val_letoh32(their.verify_len);
    int32_t result = (their.verify_crc == expected_crc) ? VAL_OK : VAL_ERR_RESUME_VERIFY;
    // Encode status as LE int32
    int32_t result_le = (int32_t)val_htole32((uint32_t)result);
    return val_internal_send_packet(s, VAL_PKT_VERIFY, &result_le, sizeof(result_le), 0);
}

static val_resume_action_t determine_resume_action(val_session_t *session, const char *filename, const char *sender_path,
                                                   uint64_t incoming_file_size, uint64_t *out_resume_offset,
                                                   uint32_t *out_verify_crc, uint32_t *out_verify_length)
{
    (void)sender_path; // not needed for determining resume
    val_resume_mode_t mode = session->config->resume.mode;

    char full_output_path[512];
    if (session->output_directory && session->output_directory[0])
    {
        snprintf(full_output_path, sizeof(full_output_path), "%s/%s", session->output_directory, filename);
    }
    else
    {
        snprintf(full_output_path, sizeof(full_output_path), "%s", filename);
    }

    void *file = session->config->filesystem.fopen(session->config->filesystem.fs_context, full_output_path, "rb");
    if (!file)
    {
        *out_resume_offset = 0;
        return VAL_RESUME_ACTION_START_ZERO;
    }

    session->config->filesystem.fseek(session->config->filesystem.fs_context, file, 0, SEEK_END);
    long existing_size = session->config->filesystem.ftell(session->config->filesystem.fs_context, file);
    if (existing_size < 0)
    {
        session->config->filesystem.fclose(session->config->filesystem.fs_context, file);
        *out_resume_offset = 0;
        return VAL_RESUME_ACTION_START_ZERO;
    }

    switch (mode)
    {
    case VAL_RESUME_NONE:
        session->config->filesystem.fclose(session->config->filesystem.fs_context, file);
        *out_resume_offset = 0;
        return VAL_RESUME_ACTION_START_ZERO;
    case VAL_RESUME_APPEND:
        if ((uint64_t)existing_size >= incoming_file_size)
        {
            session->config->filesystem.fclose(session->config->filesystem.fs_context, file);
            *out_resume_offset = 0;
            return VAL_RESUME_ACTION_START_ZERO;
        }
        session->config->filesystem.fclose(session->config->filesystem.fs_context, file);
        *out_resume_offset = (uint64_t)existing_size;
        return VAL_RESUME_ACTION_START_OFFSET;
    case VAL_RESUME_CRC_VERIFY:
    {
        if (existing_size == 0)
        {
            session->config->filesystem.fclose(session->config->filesystem.fs_context, file);
            *out_resume_offset = 0;
            return VAL_RESUME_ACTION_START_ZERO;
        }
        uint32_t verify_bytes = session->config->resume.verify_bytes ? session->config->resume.verify_bytes : 1024u;
        if (verify_bytes > (uint32_t)existing_size)
            verify_bytes = (uint32_t)existing_size;
        long seek_pos = existing_size - verify_bytes;
        session->config->filesystem.fseek(session->config->filesystem.fs_context, file, seek_pos, SEEK_SET);
        size_t bytes_read = (size_t)session->config->filesystem.fread(
            session->config->filesystem.fs_context, session->config->buffers.recv_buffer, 1, verify_bytes, file);
        session->config->filesystem.fclose(session->config->filesystem.fs_context, file);
        if (bytes_read != verify_bytes)
        {
            *out_resume_offset = 0;
            return VAL_RESUME_ACTION_START_ZERO;
        }
        *out_resume_offset = (uint64_t)existing_size;
        *out_verify_crc = val_internal_crc32(session, session->config->buffers.recv_buffer, verify_bytes);
        *out_verify_length = verify_bytes;
        return VAL_RESUME_ACTION_VERIFY_FIRST;
    }
    }
    session->config->filesystem.fclose(session->config->filesystem.fs_context, file);
    *out_resume_offset = 0;
    return VAL_RESUME_ACTION_START_ZERO;
}

static val_status_t handle_file_resume(val_session_t *s, const char *filename, const char *sender_path, uint64_t file_size,
                                       uint64_t *resume_offset_out)
{
    uint64_t resume_offset = 0;
    uint32_t verify_crc = 0;
    uint32_t verify_length = 0;
    val_resume_action_t action =
        determine_resume_action(s, filename, sender_path, file_size, &resume_offset, &verify_crc, &verify_length);
    val_status_t st = send_resume_response(s, action, resume_offset, verify_crc, verify_length);
    if (st != VAL_OK)
        return st;
    if (action == VAL_RESUME_ACTION_VERIFY_FIRST)
    {
        st = handle_verification_exchange(s, verify_crc);
        if (st == VAL_ERR_RESUME_VERIFY)
        {
            resume_offset = 0; // fall back to zero
        }
        else if (st != VAL_OK)
        {
            return st;
        }
    }
    *resume_offset_out = resume_offset;
    if (s->config->callbacks.on_file_start)
        s->config->callbacks.on_file_start(filename, sender_path, file_size, resume_offset);
    return VAL_OK;
}

val_status_t val_internal_receive_files(val_session_t *s, const char *output_directory)
{
    (void)output_directory;
    size_t P = s->effective_packet_size ? s->effective_packet_size : s->config->buffers.packet_size;
    uint8_t *tmp = (uint8_t *)s->config->buffers.recv_buffer;

    // Handshake done upon public API entry; loop to receive files until EOT
    for (;;)
    {
        // Expect metadata from sender
        val_packet_type_t t = 0;
        uint32_t len = 0;
        uint64_t off = 0;
        uint32_t to_meta = s->config->timeouts.meta_ms ? s->config->timeouts.meta_ms : 60000u;
        val_status_t st = VAL_OK;
        {
            uint8_t tries = s->config->retries.meta_retries ? s->config->retries.meta_retries : 0;
            uint32_t backoff = s->config->retries.backoff_ms_base ? s->config->retries.backoff_ms_base : 0;
            for (;;)
            {
                st = val_internal_recv_packet(s, &t, tmp, (uint32_t)P, &len, &off, to_meta);
                if (st == VAL_OK)
                    break;
                if (st != VAL_ERR_TIMEOUT || tries == 0)
                    return st;
                if (backoff && s->config->system.delay_ms)
                    s->config->system.delay_ms(backoff);
                if (backoff)
                    backoff <<= 1; // exponential
                --tries;
            }
        }
        if (t == VAL_PKT_EOT)
        {
            (void)val_internal_send_packet(s, VAL_PKT_EOT_ACK, NULL, 0, 0);
            return VAL_OK;
        }
        if (t != VAL_PKT_SEND_META || len < sizeof(val_meta_payload_t))
            return VAL_ERR_PROTOCOL;
        val_meta_payload_t meta;
        memcpy(&meta, tmp, sizeof(meta));
        // Convert numeric fields from LE
        meta.file_size = val_letoh64(meta.file_size);
        meta.file_crc32 = val_letoh32(meta.file_crc32);

        // Determine output path (receiver controls)
        char clean_name[VAL_MAX_FILENAME + 1];
        val_clean_filename(meta.filename, clean_name, sizeof(clean_name));
        char full_output_path[512];
        if (s->output_directory[0])
        {
            snprintf(full_output_path, sizeof(full_output_path), "%s/%s", s->output_directory, clean_name);
        }
        else
        {
            snprintf(full_output_path, sizeof(full_output_path), "%s", clean_name);
        }

        // Handle resume negotiation
        uint64_t resume_off = 0;
        st = handle_file_resume(s, clean_name, meta.sender_path, meta.file_size, &resume_off);
        if (st != VAL_OK)
            return st;

        // Open file for write
        const char *mode = (resume_off == 0) ? "wb" : "ab";
        void *f = s->config->filesystem.fopen(s->config->filesystem.fs_context, full_output_path, mode);
        if (!f)
            return VAL_ERR_IO;

        uint64_t written = resume_off;
        uint64_t total = meta.file_size;
        // Compute CRC across the final file contents: seed if resuming
        uint32_t crc_state = val_internal_crc32_init(s);
        if (resume_off > 0)
        {
            // Re-read existing bytes to seed CRC (could be optimized by caching)
            void *fr = s->config->filesystem.fopen(s->config->filesystem.fs_context, full_output_path, "rb");
            if (!fr)
            {
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                return VAL_ERR_IO;
            }
            uint8_t *buf_crc = (uint8_t *)s->config->buffers.recv_buffer;
            size_t step = 4096;
            uint64_t left = resume_off;
            while (left > 0)
            {
                size_t take = (left < step) ? (size_t)left : step;
                int rr = s->config->filesystem.fread(s->config->filesystem.fs_context, buf_crc, 1, take, fr);
                if (rr != (int)take)
                {
                    s->config->filesystem.fclose(s->config->filesystem.fs_context, fr);
                    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                    return VAL_ERR_IO;
                }
                crc_state = val_internal_crc32_update(s, crc_state, buf_crc, take);
                left -= take;
            }
            s->config->filesystem.fclose(s->config->filesystem.fs_context, fr);
        }
        for (;;)
        {
            t = 0;
            len = 0;
            off = 0;
            uint32_t to_data = s->config->timeouts.data_ms ? s->config->timeouts.data_ms : 60000u;
            {
                uint8_t tries = s->config->retries.data_retries ? s->config->retries.data_retries : 0;
                uint32_t backoff = s->config->retries.backoff_ms_base ? s->config->retries.backoff_ms_base : 0;
                for (;;)
                {
                    st = val_internal_recv_packet(s, &t, tmp, (uint32_t)P, &len, &off, to_data);
                    if (st == VAL_OK)
                        break;
                    if (st != VAL_ERR_TIMEOUT || tries == 0)
                    {
                        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                        return st;
                    }
                    if (backoff && s->config->system.delay_ms)
                        s->config->system.delay_ms(backoff);
                    if (backoff)
                        backoff <<= 1;
                    --tries;
                }
            }
            if (t == VAL_PKT_DATA)
            {
                // Cumulative ACK semantics
                if (off == written)
                {
                    // Normal in-order chunk
                    if (len)
                    {
                        int w = s->config->filesystem.fwrite(s->config->filesystem.fs_context, tmp, 1, len, f);
                        if (w != (int)len)
                        {
                            s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                            return VAL_ERR_IO;
                        }
                        crc_state = val_internal_crc32_update(s, crc_state, tmp, len);
                    }
                    written += len;
                }
                else if (off < written)
                {
                    // Duplicate or overlap: ignore write; do not roll back CRC
                    // No-op, fall through to ACK written
                }
                else /* off > written */
                {
                    // Sender is ahead; do not write, just re-ACK what we have
                    // No-op
                }
                if (s->config->callbacks.on_progress)
                    s->config->callbacks.on_progress(written, total);
                // Ack cumulative next expected offset (written)
                val_status_t st2 = val_internal_send_packet(s, VAL_PKT_DATA_ACK, NULL, 0, written);
                if (st2 != VAL_OK)
                {
                    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                    return st2;
                }
            }
            else if (t == VAL_PKT_DONE)
            {
                // Validate whole-file CRC
                uint32_t crc_final = val_internal_crc32_final(s, crc_state);
                if (crc_final != meta.file_crc32)
                {
                    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                    return VAL_ERR_CRC;
                }
                // Acknowledge DONE explicitly
                val_status_t st2 = val_internal_send_packet(s, VAL_PKT_DONE_ACK, NULL, 0, written);
                if (st2 != VAL_OK)
                {
                    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                    return st2;
                }
                break; // file complete
            }
            else if (t == VAL_PKT_ERROR)
            {
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                return VAL_ERR_PROTOCOL;
            }
            else if (t == VAL_PKT_SEND_META)
            {
                // Unexpected new file; for simplicity, treat as protocol error for now
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                return VAL_ERR_PROTOCOL;
            }
            else
            {
                // ignore unknowns
            }
        }
        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
        if (s->config->callbacks.on_file_complete)
            s->config->callbacks.on_file_complete(clean_name, meta.sender_path, VAL_OK);
        // Loop to wait for next file
    }
}

// Expose internal resume to match design doc naming
val_status_t val_internal_handle_file_resume(val_session_t *session, const char *filename, const char *sender_path,
                                             uint64_t file_size, uint64_t *out_resume_offset)
{
    return handle_file_resume(session, filename, sender_path, file_size, out_resume_offset);
}
