#include "val_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static val_status_t get_file_size_and_name(val_session_t *s, const char *filepath, uint64_t *out_size, char *out_filename)
{
    // Open file to determine size

    void *f = s->config->filesystem.fopen(s->config->filesystem.fs_context, filepath, "rb");
    if (!f)
        return VAL_ERR_IO;
    if (s->config->filesystem.fseek(s->config->filesystem.fs_context, f, 0, SEEK_END) != 0)
    {
        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
        return VAL_ERR_IO;
    }
    long sz = s->config->filesystem.ftell(s->config->filesystem.fs_context, f);
    if (sz < 0)
    {
        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
        return VAL_ERR_IO;
    }
    if (s->config->filesystem.fseek(s->config->filesystem.fs_context, f, 0, SEEK_SET) != 0)
    {
        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
        return VAL_ERR_IO;
    }
    *out_size = (uint64_t)sz;
    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);

    // Derive filename from filepath (simple extraction of basename)
    const char *base = filepath;
    for (const char *p = filepath; *p; ++p)
    {
        if (*p == '/' || *p == '\\')
            base = p + 1;
    }
    char cleaned[VAL_MAX_FILENAME + 1];
    val_clean_filename(base, cleaned, sizeof(cleaned));
    snprintf(out_filename, VAL_MAX_FILENAME + 1, "%s", cleaned);
    return VAL_OK;
}

static val_status_t send_metadata(val_session_t *s, const char *sender_path, uint64_t file_size, uint32_t file_crc,
                                  const char *filename)
{
    val_meta_payload_t meta;
    memset(&meta, 0, sizeof(meta));
    if (filename)
    {
        snprintf(meta.filename, VAL_MAX_FILENAME + 1, "%s", filename);
    }
    if (sender_path)
    {
        char cleaned[VAL_MAX_PATH + 1];
        val_clean_path(sender_path, cleaned, sizeof(cleaned));
        snprintf(meta.sender_path, VAL_MAX_PATH + 1, "%s", cleaned);
    }
    else
    {
        meta.sender_path[0] = '\0';
    }
    meta.file_size = val_htole64(file_size);
    meta.file_crc32 = val_htole32(file_crc);
    return val_internal_send_packet(s, VAL_PKT_SEND_META, &meta, sizeof(meta), 0);
}

static val_status_t compute_crc_region(val_session_t *s, const char *filepath, uint64_t end_offset, uint32_t length,
                                       uint32_t *out_crc)
{
    // Compute CRC over [end_offset - length .. end_offset)
    if (length == 0 || end_offset < length || !out_crc)
    {
        return VAL_ERR_INVALID_ARG;
    }
    void *f = s->config->filesystem.fopen(s->config->filesystem.fs_context, filepath, "rb");
    if (!f)
        return VAL_ERR_IO;
    uint64_t start = end_offset - length;
    if (s->config->filesystem.fseek(s->config->filesystem.fs_context, f, (long)start, SEEK_SET) != 0)
    {
        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
        return VAL_ERR_IO;
    }
    uint32_t state = val_internal_crc32_init(s);
    uint8_t *buf = (uint8_t *)s->config->buffers.recv_buffer; // reuse buffer
    while (length > 0)
    {
        size_t chunk = length > 4096 ? 4096 : length;
        int r = s->config->filesystem.fread(s->config->filesystem.fs_context, buf, 1, chunk, f);
        if (r != (int)chunk)
        {
            s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
            return VAL_ERR_IO;
        }
        state = val_internal_crc32_update(s, state, buf, chunk);
        length -= (uint32_t)chunk;
    }
    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
    *out_crc = val_internal_crc32_final(s, state);
    return VAL_OK;
}

static val_status_t request_resume_and_get_response(val_session_t *s, const char *filepath, uint64_t *resume_offset_out)
{
    val_status_t st = val_internal_send_packet(s, VAL_PKT_RESUME_REQ, NULL, 0, 0);
    if (st != VAL_OK)
        return st;
    uint8_t tmp[128];
    uint32_t len = 0;
    uint64_t off = 0;
    val_packet_type_t t = 0;
    st = val_internal_recv_packet(s, &t, tmp, sizeof(tmp), &len, &off, 10000);
    if (st != VAL_OK)
        return st;
    if (t != VAL_PKT_RESUME_RESP || len < sizeof(val_resume_resp_t))
        return VAL_ERR_PROTOCOL;
    val_resume_resp_t resp;
    memcpy(&resp, tmp, sizeof(resp));
    // Convert from LE
    resp.action = val_letoh32(resp.action);
    resp.resume_offset = val_letoh64(resp.resume_offset);
    resp.verify_crc = val_letoh32(resp.verify_crc);
    resp.verify_len = val_letoh32(resp.verify_len);
    if (resp.action == VAL_RESUME_ACTION_VERIFY_FIRST)
    {
        // Receiver expects us to send our own CRC for the requested region
        uint32_t crc = 0;
        st = compute_crc_region(s, filepath, resp.resume_offset, resp.verify_len, &crc);
        if (st != VAL_OK)
            return st;
        val_resume_resp_t verify_payload = resp;
        verify_payload.verify_crc = crc;
        // Encode to LE for wire
        val_resume_resp_t verify_le = verify_payload;
        verify_le.action = val_htole32(verify_le.action);
        verify_le.resume_offset = val_htole64(verify_le.resume_offset);
        verify_le.verify_crc = val_htole32(verify_le.verify_crc);
        verify_le.verify_len = val_htole32(verify_le.verify_len);
        st = val_internal_send_packet(s, VAL_PKT_VERIFY, &verify_le, sizeof(verify_le), 0);
        if (st != VAL_OK)
            return st;
        // Wait for verification result (ACK via VERIFY packet with action field reused as status)
        st = val_internal_recv_packet(s, &t, tmp, sizeof(tmp), &len, &off, 10000);
        if (st != VAL_OK)
            return st;
        if (t != VAL_PKT_VERIFY)
            return VAL_ERR_PROTOCOL;
        // If receiver indicates mismatch, it will have responded with VAL_ERR_RESUME_VERIFY encoded
        int32_t verify_status = 0;
        if (len >= sizeof(int32_t))
        {
            memcpy(&verify_status, tmp, sizeof(int32_t));
            // Convert from LE
            uint32_t vs_bits = (uint32_t)verify_status;
            vs_bits = val_letoh32(vs_bits);
            verify_status = (int32_t)vs_bits;
        }
        if (verify_status == VAL_ERR_RESUME_VERIFY)
        {
            *resume_offset_out = 0;
        }
        else if (verify_status != VAL_OK)
        {
            return (val_status_t)verify_status;
        }
        else
        {
            *resume_offset_out = resp.resume_offset;
        }
    }
    else if (resp.action == VAL_RESUME_ACTION_START_OFFSET)
    {
        *resume_offset_out = resp.resume_offset;
    }
    else
    {
        *resume_offset_out = 0;
    }
    return VAL_OK;
}

val_status_t val_internal_send_file(val_session_t *s, const char *filepath, const char *sender_path)
{
    // Gather meta
    uint64_t size = 0;
    char filename[VAL_MAX_FILENAME + 1];
    val_status_t st = get_file_size_and_name(s, filepath, &size, filename);
    if (st != VAL_OK)
        return st;
    // Determine reported/original path hint to include in metadata for receiver information
    const char *reported_path = (sender_path && sender_path[0]) ? sender_path : filepath;

    // Compute file CRC32 (whole file). For large files, this traverses file once upfront.
    void *fcrc = s->config->filesystem.fopen(s->config->filesystem.fs_context, filepath, "rb");
    if (!fcrc)
        return VAL_ERR_IO;
    uint32_t crc_state = val_internal_crc32_init(s);
    uint8_t *buf = (uint8_t *)s->config->buffers.recv_buffer;
    size_t chunk = (s->effective_packet_size ? s->effective_packet_size : s->config->buffers.packet_size);
    // Use a safe chunk smaller than packet to avoid buffer overrun
    if (chunk > 4096)
        chunk = 4096;
    for (;;)
    {
        int r = s->config->filesystem.fread(s->config->filesystem.fs_context, buf, 1, chunk, fcrc);
        if (r <= 0)
            break;
        crc_state = val_internal_crc32_update(s, crc_state, buf, (size_t)r);
    }
    s->config->filesystem.fclose(s->config->filesystem.fs_context, fcrc);
    uint32_t file_crc = val_internal_crc32_final(s, crc_state);

    // Send metadata
    st = send_metadata(s, reported_path, size, file_crc, filename);
    if (st != VAL_OK)
        return st;

    // Ask for resume and honor receiver's decision
    uint64_t resume_off = 0;
    st = request_resume_and_get_response(s, filepath, &resume_off);
    if (st != VAL_OK)
        return st;

    // Open file and seek to resume_off
    void *f = s->config->filesystem.fopen(s->config->filesystem.fs_context, filepath, "rb");
    if (!f)
        return VAL_ERR_IO;
    if (resume_off != 0)
    {
        if (s->config->filesystem.fseek(s->config->filesystem.fs_context, f, (long)resume_off, SEEK_SET) != 0)
        {
            s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
            return VAL_ERR_IO;
        }
    }

    // Notify start
    if (s->config->callbacks.on_file_start)
        s->config->callbacks.on_file_start(filename, reported_path ? reported_path : "", size, resume_off);

    // Send data packets
    size_t P = s->effective_packet_size ? s->effective_packet_size : s->config->buffers.packet_size;
    uint8_t *tmp = (uint8_t *)s->config->buffers.recv_buffer; // temp staging for file reads
    uint64_t sent = resume_off;
    size_t max_payload = (size_t)(P - sizeof(val_packet_header_t) - sizeof(uint32_t));
    while (sent < size)
    {
        size_t to_read = (size_t)((size - sent) < (uint64_t)max_payload ? (size - sent) : (uint64_t)max_payload);
        int r = s->config->filesystem.fread(s->config->filesystem.fs_context, tmp, 1, to_read, f);
        if (r != (int)to_read)
        {
            s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
            return VAL_ERR_IO;
        }
        st = val_internal_send_packet(s, VAL_PKT_DATA, tmp, (uint32_t)to_read, sent);
        if (st != VAL_OK)
        {
            s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
            return st;
        }
        // Wait for cumulative ACK (offset == next expected on receiver)
        uint32_t len = 0;
        uint64_t off = 0;
        val_packet_type_t t = 0;
        uint32_t to_ack = s->config->timeouts.ack_ms ? s->config->timeouts.ack_ms : 10000u;
        uint8_t tries = s->config->retries.ack_retries ? s->config->retries.ack_retries : 0;
        uint32_t backoff = s->config->retries.backoff_ms_base ? s->config->retries.backoff_ms_base : 0;
        for (;;)
        {
            st = val_internal_recv_packet(s, &t, NULL, 0, &len, &off, to_ack);
            if (st == VAL_OK)
            {
                if (t != VAL_PKT_DATA_ACK)
                {
                    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                    return VAL_ERR_PROTOCOL;
                }
                // Cumulative semantics: off == receiver's next expected offset
                if (off > sent + to_read)
                {
                    // Receiver is ahead; seek forward
                    uint64_t target = off;
                    long target_l = (long)target;
                    if (s->config->filesystem.fseek(s->config->filesystem.fs_context, f, target_l, SEEK_SET) != 0)
                    {
                        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                        return VAL_ERR_IO;
                    }
                    sent = off;
                }
                else if (off < sent)
                {
                    // Receiver expects earlier data; seek back and resume
                    long target_l = (long)off;
                    if (s->config->filesystem.fseek(s->config->filesystem.fs_context, f, target_l, SEEK_SET) != 0)
                    {
                        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                        return VAL_ERR_IO;
                    }
                    sent = off;
                }
                else
                {
                    // Normal advance: receiver accepted this chunk
                    sent = off; // equals sent + to_read in happy path
                }
                break;
            }
            if (st != VAL_ERR_TIMEOUT || tries == 0)
            {
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                return st;
            }
            // Timeout: retransmit the same DATA chunk and backoff
            val_status_t rs = val_internal_send_packet(s, VAL_PKT_DATA, tmp, (uint32_t)to_read, sent);
            if (rs != VAL_OK)
            {
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                return rs;
            }
            if (backoff && s->config->system.delay_ms)
                s->config->system.delay_ms(backoff);
            if (backoff)
                backoff <<= 1;
            --tries;
        }
        // Progress callback reflects receiver-accepted position
        if (s->config->callbacks.on_progress)
            s->config->callbacks.on_progress(sent, size);
    }

    // Signal done and wait for DONE_ACK
    st = val_internal_send_packet(s, VAL_PKT_DONE, NULL, 0, size);
    if (st != VAL_OK)
    {
        s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
        if (s->config->callbacks.on_file_complete)
            s->config->callbacks.on_file_complete(filename, reported_path ? reported_path : "", st);
        return st;
    }
    {
        val_packet_type_t t = 0;
        uint32_t len = 0;
        uint64_t off = 0;
        uint32_t to = s->config->timeouts.ack_ms ? s->config->timeouts.ack_ms : 10000u;
        uint8_t tries = s->config->retries.ack_retries ? s->config->retries.ack_retries : 0;
        uint32_t backoff = s->config->retries.backoff_ms_base ? s->config->retries.backoff_ms_base : 0;
        for (;;)
        {
            st = val_internal_recv_packet(s, &t, NULL, 0, &len, &off, to);
            if (st == VAL_OK && t == VAL_PKT_DONE_ACK)
                break;
            if (st != VAL_OK && st != VAL_ERR_TIMEOUT)
            {
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                if (s->config->callbacks.on_file_complete)
                    s->config->callbacks.on_file_complete(filename, reported_path ? reported_path : "", st);
                return st;
            }
            if (tries == 0)
            {
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                if (s->config->callbacks.on_file_complete)
                    s->config->callbacks.on_file_complete(filename, reported_path ? reported_path : "", VAL_ERR_TIMEOUT);
                return VAL_ERR_TIMEOUT;
            }
            // Retransmit DONE on timeout or wrong packet
            val_status_t rs = val_internal_send_packet(s, VAL_PKT_DONE, NULL, 0, size);
            if (rs != VAL_OK)
            {
                s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
                if (s->config->callbacks.on_file_complete)
                    s->config->callbacks.on_file_complete(filename, reported_path ? reported_path : "", rs);
                return rs;
            }
            if (backoff && s->config->system.delay_ms)
                s->config->system.delay_ms(backoff);
            if (backoff)
                backoff <<= 1;
            --tries;
        }
    }
    s->config->filesystem.fclose(s->config->filesystem.fs_context, f);
    if (s->config->callbacks.on_file_complete)
        s->config->callbacks.on_file_complete(filename, reported_path ? reported_path : "", st);
    return st;
}

val_status_t val_send_files(val_session_t *s, const char *const *filepaths, size_t file_count, const char *sender_path)
{
    if (!s || !filepaths || file_count == 0)
        return VAL_ERR_INVALID_ARG;
    // Coarse-grained session lock to keep send operations thread-safe per session
#if defined(_WIN32)
    EnterCriticalSection(&s->lock);
#else
    pthread_mutex_lock(&s->lock);
#endif
    // Validate local features before any handshake; requested gets sanitized, required must be supported locally
    extern val_status_t val_internal_do_handshake_sender(val_session_t * s);
    val_status_t hs = val_internal_do_handshake_sender(s);
    if (hs != VAL_OK)
    {
#if defined(_WIN32)
        LeaveCriticalSection(&s->lock);
#else
        pthread_mutex_unlock(&s->lock);
#endif
        return hs;
    }
    for (size_t i = 0; i < file_count; ++i)
    {
        val_status_t st = val_internal_send_file(s, filepaths[i], sender_path);
        if (st != VAL_OK)
        {
#if defined(_WIN32)
            LeaveCriticalSection(&s->lock);
#else
            pthread_mutex_unlock(&s->lock);
#endif
            return st;
        }
    }
    // Send EOT and wait for ACK automatically
    val_status_t st = val_internal_send_packet(s, VAL_PKT_EOT, NULL, 0, 0);
    if (st != VAL_OK)
    {
#if defined(_WIN32)
        LeaveCriticalSection(&s->lock);
#else
        pthread_mutex_unlock(&s->lock);
#endif
        return st;
    }
    val_packet_type_t t = 0;
    uint32_t len = 0;
    uint64_t off = 0;
    uint32_t to = s->config->timeouts.ack_ms ? s->config->timeouts.ack_ms : 10000u;
    st = val_internal_recv_packet(s, &t, NULL, 0, &len, &off, to);
    if (st != VAL_OK)
    {
#if defined(_WIN32)
        LeaveCriticalSection(&s->lock);
#else
        pthread_mutex_unlock(&s->lock);
#endif
        return st;
    }
    val_status_t out = (t == VAL_PKT_EOT_ACK) ? VAL_OK : VAL_ERR_PROTOCOL;
#if defined(_WIN32)
    LeaveCriticalSection(&s->lock);
#else
    pthread_mutex_unlock(&s->lock);
#endif
    return out;
}
